import { Button } from 'reactstrap';
import React from 'react'

export default ({text}) => {
    return (
        <Button color="danger">{text}</Button>
    );
};